"""PLC stack app package.

The public surface here intentionally exposes a builder (`build_core`) so tests can use
the *real app wiring* while swapping the device implementation (SIM vs PLC).
"""

from .builder import PlcStackRuntime, build_core, collect_axes  # noqa: F401
