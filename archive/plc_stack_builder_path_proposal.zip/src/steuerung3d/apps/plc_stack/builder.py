from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from steuerung3d.common.timebase import Timebase
from steuerung3d.config.plc_stack_config import PlcStackConfig
from steuerung3d.core.engine import CoreEngine
from steuerung3d.core.intent_handler import apply_intent
from steuerung3d.core.state import MachineState
from steuerung3d.protocol.recording import JsonlRecorder, LoggedTransport
from steuerung3d.protocol.transport import InMemTransport


DeviceStep = Callable[[MachineState, object, float], None]
# Note: device_step signature in the current engine is (state, command_frame, dt).
# We intentionally type 'command_frame' as 'object' here to avoid importing protocol types
# into the app boundary and to keep the builder usable with SIM or PLC devices.


@dataclass
class PlcStackRuntime:
    cfg: PlcStackConfig
    transport: InMemTransport  # may be wrapped at runtime (see build_transport)
    timebase: Timebase
    state: MachineState
    engine: CoreEngine


def collect_axes(cfg: PlcStackConfig) -> list[str]:
    axes: list[str] = []
    for ep in cfg.plc_endpoints:
        axes.extend(ep.axis_ids)
    # de-dup while preserving order
    seen = set()
    out: list[str] = []
    for a in axes:
        if a not in seen:
            out.append(a)
            seen.add(a)
    return out


def build_transport(cfg: PlcStackConfig) -> tuple[InMemTransport, Optional[JsonlRecorder]]:
    raw = InMemTransport()
    rec = JsonlRecorder(Path(cfg.app.log_path))
    transport = LoggedTransport(raw, rec)  # type: ignore[assignment]
    return transport, rec


def build_core(cfg: PlcStackConfig, *, device_step: DeviceStep, enable_logging: bool = True) -> PlcStackRuntime:
    """
    Build the PLC stack core runtime using *the real app wiring*:

    - axes are derived from cfg.plc_endpoints[*].axis_ids
    - transport is InMemTransport (optionally wrapped with JSONL logging)
    - engine is CoreEngine with apply_intent and provided device_step

    This function is used by:
      - apps/plc_stack/__main__.py (PLC device)
      - tests (SIM device) to validate "config -> axes -> engine behavior" without PLCs.
    """
    transport: InMemTransport
    rec = None
    if enable_logging:
        transport, rec = build_transport(cfg)
    else:
        transport = InMemTransport()

    tb = Timebase(dt_s=float(cfg.app.dt_s))
    st = MachineState()
    for a in collect_axes(cfg):
        st.ensure_axis(a)

    eng = CoreEngine(
        timebase=tb,
        state=st,
        drain_intents=transport.drain_intents,
        handle_intent=apply_intent,
        device_step=device_step,
        on_snapshot=getattr(transport, "publish_telemetry"),
        on_command_frame=(rec.record_command_frame if rec is not None else None),
    )

    return PlcStackRuntime(cfg=cfg, transport=transport, timebase=tb, state=st, engine=eng)
